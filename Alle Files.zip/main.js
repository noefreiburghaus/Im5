fetch('Daten.json')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector('tbody');
        tableBody.innerHTML = '';
    
        for (const property in data[0]) { // Only take the properties of the first item
            const row = document.createElement('tr');

    
            const cellValue1 = document.createElement('td');
            cellValue1.textContent = data[0][property];
            row.appendChild(cellValue1);

            const cellKey = document.createElement('td');
            cellKey.textContent = property;
            row.appendChild(cellKey);
    
            const cellValue2 = document.createElement('td');
            cellValue2.textContent = data[1][property];
            row.appendChild(cellValue2);
    
            tableBody.appendChild(row);
        }
    })
    .catch(error => console.error('Fehler:', error));

window.onload = function() {
    var colorButton = document.getElementById('colorButton');
    var isColorBlack = true;

    colorButton.addEventListener('click', function() {
        var textElements = document.getElementsByTagName('td');

        

        for (var i = 0; i < textElements.length; i++) {
            if(textElements[i].parentNode.children[1]!==textElements[i]){
            textElements[i].style.backgroundColor = isColorBlack ? '#ffffff00' : '#000000';
            textElements[i].style.transition = "background-color 0.2s ease";

            if (isColorBlack) {
                textElements[i].addEventListener('mouseover', function() {
                    this.style.backgroundColor = '#ffffff';
                });
                textElements[i].addEventListener('mouseout', function() {
                    this.style.backgroundColor = '#ffffff';
                });
            } else {
                textElements[i].addEventListener('mouseover', function() {
                    this.style.backgroundColor = '#ffffff';
                });
                textElements[i].addEventListener('mouseout', function() {
                    this.style.backgroundColor = '#000000';
            });
            }}


            function updateButtonLabel() {
                if (isColorBlack) {
                    colorButton.textContent = 'Quiz Modus';
            } else {
                    colorButton.textContent = 'Lösung';
                }
            }
            updateButtonLabel();

        }
        isColorBlack = !isColorBlack;
    });
};


const menu = document.querySelector('.menu');

        function openMenu() {
            menu.classList.add('show-menu');
        }

        function closeMenu() {
            menu.classList.remove('show-menu');
        }